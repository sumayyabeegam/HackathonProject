package mini_project;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel 

	 {
		 public static String getExcelData() throws IOException {
			 String s=System.getProperty("user.dir")+"\\Excel"+"\\TESTDATA.xlsx";
			 FileInputStream file=new FileInputStream(s);
			 
			 XSSFWorkbook work=new XSSFWorkbook(file);
			 XSSFSheet sheet=work.getSheetAt(0);
			 XSSFRow row=sheet.getRow(0);
			 XSSFCell cell=row.getCell(0);
			 
	String data=cell.toString();
	         return data;
		 }
		

	}


